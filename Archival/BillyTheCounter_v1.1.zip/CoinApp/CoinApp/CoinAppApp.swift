//
//  CoinAppApp.swift
//  CoinApp
//
//  Created by Zach Huang on 2025/2/18.
//

import SwiftUI

@main
struct CoinAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
