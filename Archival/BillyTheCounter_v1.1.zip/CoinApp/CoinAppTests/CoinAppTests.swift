//
//  CoinAppTests.swift
//  CoinAppTests
//
//  Created by Zach Huang on 2025/2/18.
//

import Testing
@testable import CoinApp

struct CoinAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
